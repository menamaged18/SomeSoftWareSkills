public class NOT_EXIST_EXCEPTION extends Exception {
    NOT_EXIST_EXCEPTION () {
        super();
    }

}
